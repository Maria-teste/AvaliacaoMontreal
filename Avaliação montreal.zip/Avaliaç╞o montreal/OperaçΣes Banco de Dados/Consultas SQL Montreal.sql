/*Select que retorna os dados: Nome Usuário; Logradouro; Bairro; Número Logradouro; Telefone; CPF; Login; Senha; Nome Credor; Telefone Credor; E-mail Credor;*/
SELECT usr.nm_usuario, erd.nm_logradouro, erd.nm_bairro, erd.nu_logradouro, usr.nu_telefone_1, 
usr.nu_telefone_2, usr.nu_cpf,  usr.nu_login, usr.nu_senha, crd.nm_credor, crd.nu_telefone_1,
crd.nu_telefone_2, crd.ds_email
FROM credores crd
INNER JOIN usuarios usr
ON crd.id_credor=usr.id_credor
INNER JOIN enderecos erd
ON usr.id_usuario_atualiza = erd.id_usuario_atualiza
-------------------------------------------------------------------------------------------------------------------------
/*Select que retorna os dados: Nome Usuário; Logradouro; Bairro; Número Logradouro; Telefone; CPF; Login; Senha; Nome Credor; Telefone Credor; E-mail Credor;*/
SELECT MIN(usr.nu_matricula), MAX(edr.nm_logradouro) FROM enderecos edr
INNER JOIN usuarios usr
ON usr.id_usuario_atualiza = edr.id_usuario_atualiza
--------------------------------------------------------------------------------------------------------------------------
/*Exclusão do registro da tabela de usuarios */
DELETE FROM usuarios WHERE id_usuario=1
---------------------------------------------------------------------------------------------------------------------------
/*Atualiza o Nome e o e-mail da tabela de usuarios*/
/*Atualiza o Logradouro e o número da tabela de enderecos*/
UPDATE usuarios SET nm_usuario='Maria', ds_email='mariaterezinhagomes@gmail.com' where id=2
UPDATE enderecos SET nm_logradouro='Rua A', nu_logradouro='126' where id_endereço=2
----------------------------------------------------------------------------------------------------------------------------
/*Insere dados na tabela de endereços*/
INSERT INTO enderecos(nu_cep, nm_logradouro, tx_complemento, nm_bairro, nu_logradouro, dt_ult_atualiza, id_municipio, id_usuario_atualiza)
VALUES("32073-010", 127, "apt 2 bloco C, "São João", "17/05/2020", 3, 4)
INSERT INTO enderecos VALUES("32073-010", 127, "apt 2 bloco C, "São João", "17/05/2020", 3, 4)
