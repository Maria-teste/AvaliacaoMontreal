package br.ce.wcaquino.runners;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features ="src/test/resources/features/avaliacaomontreal.feature",
		glue = "br.ce.wcaquino.steps",
		plugin = "pretty",
		monochrome =true,
		dryRun=false
		)
public class Runner {
}

