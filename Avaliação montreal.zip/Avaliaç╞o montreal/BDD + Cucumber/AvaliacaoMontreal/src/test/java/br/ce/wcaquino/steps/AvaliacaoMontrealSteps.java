package br.ce.wcaquino.steps;

import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Quando;
import cucumber.api.java.pt.Então;

public class AvaliacaoMontrealSteps {
	@Dado("^que eu pertença ao grupo de administrador, gestor ou analista$")
	public void que_eu_pertença_ao_grupo_de_administrador_gestor_ou_analista() throws Throwable {
	}

	@Quando("^acesso o menu empresa$")
	public void acesso_o_menu_empresa() throws Throwable {
	}

	@Quando("^vejo a listagem de empresas$")
	public void vejo_a_listagem_de_empresas() throws Throwable {
	}

	@Quando("^clico no botao filtrar$")
	public void clico_no_botao_filtrar() throws Throwable {
	}

	@Quando("^informo os dados para pesquisa$")
	public void informo_os_dados_para_pesquisa() throws Throwable {
	}

	@Quando("^clico em pesquisar$")
	public void clico_em_pesquisar() throws Throwable {
	}

	@Então("^a tela de listagem de empresas é apresentada de acordo com os dados da pesquisa realizada$")
	public void a_tela_de_listagem_de_empresas_é_apresentada_de_acordo_com_os_dados_da_pesquisa_realizada() throws Throwable {
	}

	@Quando("^clico em tipo de fornecimento$")
	public void clico_em_tipo_de_fornecimento() throws Throwable {
	}
	
	@Quando("^vejo a listagem de tipo de fornecimento$")
	public void vejo_a_listagem_de_tipo_de_fornecimento() throws Throwable {
	}

	@Então("^a tela de listagem de tipo de fornecimento é apresentada de acordo com os dados da pesquisa realizada$")
	public void a_tela_de_listagem_de_tipo_de_fornecimento_é_apresentada_de_acordo_com_os_dados_da_pesquisa_realizada() throws Throwable {
	}

	@Dado("^que a empresa não exista$")
	public void que_a_empresa_não_exista() throws Throwable {
	}

	@Dado("^que o CNPJ seja válido$")
	public void que_o_CNPJ_seja_válido() throws Throwable {
	}

	@Dado("^que a Razão Social não exista$")
	public void que_a_Razão_Social_não_exista() throws Throwable {
	}

	@Dado("^que o CNPJ sejá válido$")
	public void que_o_CNPJ_sejá_válido() throws Throwable {
	}

	@Quando("^acesso o menu empresas$")
	public void acesso_o_menu_empresas() throws Throwable {
	}

	@Quando("^clico no botao nova empresa$")
	public void clico_no_botao_nova_empresa() throws Throwable {
	}

	@Quando("^preencho os campos obrigatórios$")
	public void preencho_os_campos_obrigatórios() throws Throwable {
	}

	@Quando("^clico no botão criar$")
	public void clico_no_botão_criar() throws Throwable {
	}

	@Então("^é cadastrada uma nova empresa$")
	public void é_cadastrada_uma_nova_empresa() throws Throwable {
	}

	@Então("^a tela de empresa Ver Empresa é apresentada com a mensagem informando que a empresa \"([^\"]*)\" foi criada$")
	public void a_tela_de_empresa_Ver_Empresa_é_apresentada_com_a_mensagem_informando_que_a_empresa_foi_criada(String arg1) throws Throwable {
	}

	@Quando("^o acesso o menu empresa$")
	public void o_acesso_o_menu_empresa() throws Throwable {
	}

	@Quando("^clico no botao novo tipo de fornecimento$")
	public void clico_no_botao_novo_tipo_de_fornecimento() throws Throwable {
	}

	@Quando("^preencho todos os campos obrigatórios$")
	public void preencho_todos_os_campos_obrigatórios() throws Throwable {
	}

	@Quando("^clico em criar$")
	public void clico_em_criar() throws Throwable {
	}

	@Então("^é cadastrado um novo tipo de fornecimento$")
	public void é_cadastrado_um_novo_tipo_de_fornecimento() throws Throwable {
	}

	@Então("^a tela de Associar fornecimento é apresentada com a mensagem informando que o tipo de fornecimento \"([^\"]*)\" foi criado$")
	public void a_tela_de_Associar_fornecimento_é_apresentada_com_a_mensagem_informando_que_o_tipo_de_fornecimento_foi_criado(String arg1) throws Throwable {
	}

	@Dado("^que eu tenha empresa cadastrada$")
	public void que_eu_tenha_empresa_cadastrada() throws Throwable {
	}

	@Dado("^que eu tenha tipo de fornecimento cadastrado$")
	public void que_eu_tenha_tipo_de_fornecimento_cadastrado() throws Throwable {
	}

	@Quando("^clico em Empresas$")
	public void clico_em_Empresas() throws Throwable {
	}

	@Quando("^vejo a listagem de empresa$")
	public void vejo_a_listagem_de_empresa() throws Throwable {
	}

	@Quando("^clico no botao ver de determinada empresa$")
	public void clico_no_botao_ver_de_determinada_empresa() throws Throwable {
	}

	@Então("^é exibida a tela Ver empresa contendo os dados de cadastro da empresa$")
	public void é_exibida_a_tela_Ver_empresa_contendo_os_dados_de_cadastro_da_empresa() throws Throwable {
	}

	@Dado("^que eu tenha Tipo de Fornecimento já cadastrado$")
	public void que_eu_tenha_Tipo_de_Fornecimento_já_cadastrado() throws Throwable {
	}

	@Dado("^que eu tenha tipo de fornecimento já vinculado á empresa$")
	public void que_eu_tenha_tipo_de_fornecimento_já_vinculado_á_empresa() throws Throwable {
	}

	@Quando("^clico em Tipo de Fornecimento$")
	public void clico_em_Tipo_de_Fornecimento() throws Throwable {
	}

	@Quando("^clico no botão tipo de fornecimento$")
	public void clico_no_botão_tipo_de_fornecimento() throws Throwable {
	}

	@Quando("^clico no botão Novo Tipo de Fornecimento$")
	public void clico_no_botão_Novo_Tipo_de_Fornecimento() throws Throwable {
	}

	@Quando("^vejo a tela de Criar Tipo de Fornecimento$")
	public void vejo_a_tela_de_Criar_Tipo_de_Fornecimento() throws Throwable {
	}

	@Quando("^seleciono o tipo de fornecimento$")
	public void seleciono_o_tipo_de_fornecimento() throws Throwable {
	}

	@Então("^o Tipo de Fornecimento é vinculado á Empresa$")
	public void o_Tipo_de_Fornecimento_é_vinculado_á_Empresa() throws Throwable {
	}

	@Então("^a tela de listagem de Tipo de fornecimento é exibida com os tipos associados$")
	public void a_tela_de_listagem_de_Tipo_de_fornecimento_é_exibida_com_os_tipos_associados() throws Throwable {
	}

	@Dado("^tenha empresa cadastrada$")
	public void tenha_empresa_cadastrada() throws Throwable {
	}

	@Dado("^esteja na tela de empresa$")
	public void esteja_na_tela_de_empresa() throws Throwable {
	}

	@Quando("^informo o nome de uma empresa cadastrada$")
	public void informo_o_nome_de_uma_empresa_cadastrada() throws Throwable {
	}

	@Quando("^clico no botao criar$")
	public void clico_no_botao_criar() throws Throwable {
	}

	@Então("^o sinal de alerta é exibido informando que o CNPJ valor \"([^\"]*)\" deve ser unico$")
	public void o_sinal_de_alerta_é_exibido_informando_que_o_CNPJ_valor_deve_ser_unico(String arg1) throws Throwable {
	}

	@Dado("^esteja na tela de pesquisa$")
	public void esteja_na_tela_de_pesquisa() throws Throwable {
	}

	@Quando("^informo um dado incorreto ou inexistente$")
	public void informo_um_dado_incorreto_ou_inexistente() throws Throwable {
	}

	@Quando("^clico no botao pesquisar$")
	public void clico_no_botao_pesquisar() throws Throwable {
	}

	@Então("^o sinal de alerta é exibido informando que nenhum registro foi encontrado$")
	public void o_sinal_de_alerta_é_exibido_informando_que_nenhum_registro_foi_encontrado() throws Throwable {
	}

	@Dado("^esteja na tela de associação do tipo de fornecimento$")
	public void esteja_na_tela_de_associação_do_tipo_de_fornecimento() throws Throwable {
	}

	@Quando("^vou excluir uma empresa$")
	public void vou_excluir_uma_empresa() throws Throwable {
	}

	@Quando("^confirmo a exclusão$")
	public void confirmo_a_exclusão() throws Throwable {
	}

	@Quando("^clico no botao excluir$")
	public void clico_no_botao_excluir() throws Throwable {
	}

	@Então("^a tela de listagem de empresa é apresentada$")
	public void a_tela_de_listagem_de_empresa_é_apresentada() throws Throwable {
	}

	@Então("^vejo o sinal de alerta informando que o registro não pode ser excluido pois esta relacionado a outros registros$")
	public void vejo_o_sinal_de_alerta_informando_que_o_registro_não_pode_ser_excluido_pois_esta_relacionado_a_outros_registros() throws Throwable {
	}

	@Dado("^tenha tipo de fornecimento já vinculado a empresa$")
	public void tenha_tipo_de_fornecimento_já_vinculado_a_empresa() throws Throwable {
	}

	@Quando("^vou associar um tipo de fornecimento a empresa$")
	public void vou_associar_um_tipo_de_fornecimento_a_empresa() throws Throwable {
	}

	@Quando("^informo um tipo de fornecimento ja vinculado$")
	public void informo_um_tipo_de_fornecimento_ja_vinculado() throws Throwable {
	}

	@Então("^o sinal de alerta é exibido informando que o tipo de fornecimento com o valor \"([^\"]*)\" deve ser unico$")
	public void o_sinal_de_alerta_é_exibido_informando_que_o_tipo_de_fornecimento_com_o_valor_deve_ser_unico(String arg1) throws Throwable {
	}

	@Quando("^informo um CNPJ inválido ao editar ou excluir$")
	public void informo_um_CNPJ_inválido_ao_editar_ou_excluir() throws Throwable {
	}

	@Então("^o sinal de alerta é exibido informando que o CNPJ é inválido$")
	public void o_sinal_de_alerta_é_exibido_informando_que_o_CNPJ_é_inválido() throws Throwable {
	}

	@Quando("^informo um razão social já cadastrada$")
	public void informo_um_razão_social_já_cadastrada() throws Throwable {
	}

	@Então("^o sinal de alerta é exibido informEo que o nome \"([^\"]*)\" deve ser único$")
	public void o_sinal_de_alerta_é_exibido_informEo_que_o_nome_deve_ser_único(String arg1) throws Throwable {
	}
}